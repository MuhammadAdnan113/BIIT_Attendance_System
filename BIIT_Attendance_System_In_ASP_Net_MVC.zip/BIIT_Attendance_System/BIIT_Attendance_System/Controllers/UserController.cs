﻿using BIIT_Attendance_System.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BIIT_Attendance_System.Controllers;
using System.Net.Mail;
using System.IO;

namespace BIIT_Attendance_System.Controllers
{
    public class UserController : Controller
    {
        static string constr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);
        //
        // GET: /User/
//=========SignUp===============================
        [HttpGet]
        public ActionResult SignUp()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SignUp(User u)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var allowedExtensions = new[] { ".bmp", ".png", ".jpg", ".gif", ".jpeg" };
                    var nameoffile = u.FileAttachment.FileName;
                    var ext = Path.GetExtension(nameoffile);

                    
                    //getting  the  extension(ex-.jpg)
                    if (allowedExtensions.Contains(ext))  //check  what  type of  extension
                    {
                        //~/Images  is  relative  path  for  images  in  root  directory
                        var path = Path.Combine(Server.MapPath("~/images"), nameoffile);

                        //saving  photo  of  employee  in  the  image  folder
                        //  file.SaveAs  Saves  the  contents  of  an  uploaded  file  to  a  specified path on the Web server.
                        u.FileAttachment.SaveAs(path);

                        u.ImageURL = "~/images/" + nameoffile;

                    }
                    else
                    {
                        ViewBag.message = "Please  choose  only  Image  file";
                        return View(u);
                    }

                    string uid = u.Email.Split('@')[0].ToString();
                    ViewBag.id = uid;

                    string query = @"insert into Login(Id,FirstName,LastName,UserName,Pass,Email,ImageURL) values('" + uid + "','" + u.FirstName + "','" + u.LastName + "','" + u.UserName + "','" + u.Pass + "','" + u.Email + "','" + u.ImageURL + "')";
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    ViewBag.state = "Registered Success";
                    return View(u);
                }

            }
            catch (Exception er)
            {
                Response.Write(er.Message);
            }
            return View(u);

//=========================OLD CODE=============================
            //BinaryReader br = new BinaryReader(u.FileAttachment.InputStream);
            //u.Image = Convert.ToBase64String(
            //br.ReadBytes(u.FileAttachment.ContentLength));
            //u.ImageType = u.FileAttachment.ContentType;

            //string uid = u.Email.Split('@')[0].ToString();
            //ViewBag.id = uid;
            //con.Open();
            //query = "insert into Login(Id,FirstName,LastName,UserName,Pass,Email,Imagetype,Image) values('" + uid + "','" + u.FirstName + "','" + u.LastName + "','" + u.UserName + "','" + u.Pass + "','" + u.Email + "','" + u.ImageType + "','" + u.Image + "')";
            //SqlCommand cmd = new SqlCommand(query, con);
            //cmd.ExecuteNonQuery();
            //con.Close();
            //ViewBag.state = "Registered Success";
            //return View();
        }
//=========SignUp End===============================

//=========LogIn===============================

        [HttpGet]
        public ActionResult LogIn()
        {

            if (Session["id"] != null && Session["username"] != null)
            {
                return RedirectToAction("HomePage");
            }
            
            return View();
        }//end

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogIn(User u)
        {
            con.Open();
            string query = "select Id,Username,Pass,ImageURL from Login where userName='" + u.UserName + "' and Pass='" + u.Pass + "'";
            SqlCommand cmd = new SqlCommand(query, con);

            SqlDataReader sdr = cmd.ExecuteReader();
            sdr.Read();
            if (sdr.HasRows)
            {
                Session["id"] = sdr["Id"].ToString(); //user ID
                Session["username"] = sdr["UserName"].ToString(); // User Name
                Session["pass"] = sdr["Pass"].ToString(); //user ID
                Session["Image"] = sdr["ImageURL"].ToString();
                
                

            }
            else
            {
                Response.Write("<script>alert('Invalid UserName or Password'); <script/>");
            }
            sdr.Close();
            con.Close();

            return RedirectToAction("HomePage", "Home");

        }//end

//=========LogIn End===============================

//=========Logout===============================
        [HttpGet]
        public ActionResult LogOut()
        {
            Session.RemoveAll();
            Session.Abandon();

            return RedirectToAction("LogIn","User");

        }// End

//=========Logout End===============================

//=========Contact===============================

        [HttpGet]
        public ActionResult Contact()
        {
            ViewBag.Message = "";
            return View();

        }// End

        [HttpPost]
        public ActionResult Contact(Contact cm)
        {
            if(ModelState.IsValid)
            {
                try
                {
                    MailMessage msz = new MailMessage();
                    msz.From = new MailAddress(cm.Email);//Email which you are getting 
								//from contact us page 
                    msz.To.Add("Email@gmail.com");//Where mail will be sent 
                    msz.Subject = cm.Subject;
                    msz.Body = cm.Message;
                    SmtpClient smtp = new SmtpClient();

                    smtp.Host = "smtp.gmail.com";

                    smtp.Port = 587;
                    smtp.EnableSsl = true;
                    smtp.Credentials = new System.Net.NetworkCredential("Email@gmail.com", "Pass");


                    smtp.Send(msz);

                    ModelState.Clear();
                    ViewBag.Message = "Thank you for Contacting us ";
                }
                catch(Exception ex )
                {
                    ModelState.Clear();
                    ViewBag.Message = " Sorry we are facing Problem here {ex.Message}";
                }              
            }
          
            return View();
        }
        public ActionResult Error()
        {
            return View();
        }//end

//=========Contact End===============================

        [HttpGet]
        public ActionResult HomePage()
        {
            return RedirectToAction("HomePage", "Home");
        }//end

        [HttpGet]
        public ActionResult Index()
        {
            return RedirectToAction("Index", "Home");
        }//end

    }// End Controller
}
