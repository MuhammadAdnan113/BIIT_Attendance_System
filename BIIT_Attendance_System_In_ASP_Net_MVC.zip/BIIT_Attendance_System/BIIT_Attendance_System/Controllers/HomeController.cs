﻿using System;
using BIIT_Attendance_System.Models;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.SqlClient;
using System.Configuration;
using BIIT_Attendance_System.Controllers;
using System.IO;

namespace BIIT_Attendance_System.Controllers
{
    public class HomeController : Controller
    {
        
        static string constr = ConfigurationManager.ConnectionStrings["constring"].ConnectionString;
        SqlConnection con = new SqlConnection(constr);

        //
        // GET: /Home/
        //========Index==================================================
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }


        //====================================================================================

        //=============About========================================
        [HttpGet]
        public ActionResult About()
        {
            return View();
        }
        //====================================================================================

        //=============HomePage========================================

        [HttpGet]
        public ActionResult HomePage()
        {
            
            if (Session["id"] != null && Session["username"] != null && Session["pass"] != null)
            {

                List<TimeTable> al = TimeTable();
                return View(al);
            }
        
            return RedirectToAction("LogIn", "User");

        }// End
        public string user = "";


        private List<TimeTable> TimeTable()
        {
            List<TimeTable> al = new List<TimeTable>();

            SqlConnection con = new SqlConnection(constr);
            con.Open();


            string q = "Select * from TimeTable where Id='" + Session["id"] + "'";
            SqlCommand cmd = new SqlCommand(q, con);
            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                TimeTable a = new TimeTable();
                a.ID = sdr["Id"].ToString();
                a.Class = sdr["Class"].ToString();
                a.Section = sdr["Section"].ToString();
                a.Subject = sdr["Subject"].ToString();
                a.Time = sdr["Time"].ToString();

                al.Add(a);
            }

            con.Close();

            return al;
        }//end
        //=============HomePage End======================================== 

        //=============Students======================================== 

        private List<Student> GetStudents(string clas,string sec,string subj)
        {
            List<Student> al = new List<Student>();
            con.Open();
            string query = "SELECT * from Students where RegNo in(select RegNo from Class where Class='" + clas + "' and Section='" + sec + "' and Subj='" + subj + "' and Id='"+Session["id"]+"')";
            SqlCommand cmd = new SqlCommand(query, con);

            SqlDataReader sdr = cmd.ExecuteReader();
            while (sdr.Read())
            {
                Student a = new Student();
                a.ID = sdr["Id"].ToString();
                a.RegNo = sdr["RegNo"].ToString();
                a.FirstName = sdr["FirstName"].ToString();
                a.LastName = sdr["LastName"].ToString();
                a.Gender = sdr["Gender"].ToString();

                al.Add(a);
            }
            sdr.Close();
            con.Close();

            return al;
        }//end   

        

        List<Student> slist;
       
        [HttpGet]
        public ActionResult Students(string clas, string sec ,string subj)
        {
            

            slist = new List<Student>();
            if (clas== null)
            {
                slist = GetStudents(Session["clas"].ToString(), Session["sec"].ToString(), Session["subj"].ToString());
                return View(slist);
            }
            else
            {
                 Session["clas"] = clas;
                 Session["sec"] = sec;
                 Session["subj"]=subj;
                 slist = GetStudents(clas,sec,subj);
                return View(slist);
            }
            

        }// End

      //=============Students======================================== 
        public string date1 = System.DateTime.Now.ToLongDateString();


        [HttpGet]
        public ActionResult Attendance(string id, string att, string regno)
        {

                con.Open();
                string query = "insert into Attendance(UserId,RegNo,Date_time,Attendance) values('"+id+"','"+regno+"','"+date1+"','"+att+"')";
                SqlCommand cmd = new SqlCommand(query, con);

                cmd.ExecuteNonQuery();
                con.Close();
                return RedirectToAction("Students", "Home");

        }// End

        //=============Student End========================================        



        //private void addcol()
        //{
        //        con.Open();
        //        string query = "ALTER TABLE Students ADD " + date1 + " varchar(12)";
        //        SqlCommand cmd = new SqlCommand(query, con);
        //        cmd.ExecuteNonQuery();
        //        con.Close();
        //}



    }// end of Controller

}
