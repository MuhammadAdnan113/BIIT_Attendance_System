﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BIIT_Attendance_System.Models
{
    public class TimeTable
    {

        public string ID { get; set; }

        [Required(ErrorMessage = "Teacher Name is Required")]
        [Display(Name = "Teacher Name")]
        public string RegNo { get; set; }

        [Required(ErrorMessage = "Class Name is Required")]
        [Display(Name = "Class Name")]
        public string Class { get; set; }

        [Required(ErrorMessage = "Section is Required")]
        [Display(Name = "Section Name")]
        public string Section { get; set; }

        [Required(ErrorMessage = "Subject Name is Required")]
        [Display(Name = "Subject Name")]
        public string Subject { get; set; }


        [Display(Name = "Time Name")]
        public string Time { get; set; }
    }
}