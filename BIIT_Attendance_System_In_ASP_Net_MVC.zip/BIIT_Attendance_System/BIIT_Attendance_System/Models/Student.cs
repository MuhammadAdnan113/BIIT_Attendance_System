﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BIIT_Attendance_System.Models
{
    public class Student
    {
        [Display(Name = "ID")]
        public string ID { get; set; }

        [Required(ErrorMessage = "Reg No is Required")]
        [Display(Name = "Reg No")]
        public string RegNo { get; set; }
        
        [Required(ErrorMessage = "First Name is Required")]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name is Required")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Gender is Required")]
        [Display(Name = "Gender")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Class is Required")]
        [Display(Name = "Class")]
        public string Class { get; set; }

        [Required(ErrorMessage = "Section is Required")]
        [Display(Name = "Section")]
        public string Section { get; set; }

        [Required(ErrorMessage = "Subj is Required")]
        [Display(Name = "Subj Name")]
        public string Subj { get; set; }

        [Required(ErrorMessage = "Attendance is Required")]
        [Display(Name = "Attendance")]
        public string Att { get; set; }

    }
}